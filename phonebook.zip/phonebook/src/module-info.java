module newJavaProject {
}