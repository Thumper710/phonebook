package phonebook;

import java.util.Scanner;

public class Menu {

	static Scanner input = new Scanner(System.in); // creates static Scanner object input

	public Menu() {
	};

	public static void startMainMenu() { // start of main menu code that calls to the main class

		boolean isEnd = false; // sets a boolean for the do while
								// loop to allow menu to reset after an entry
		try {

			do { // do start\

				System.out.println("________________________________");
				System.out.println("Welcome to the Phonebook. Please");
				System.out.println("choose from the options below\n");

				System.out.println("A. Display contacts");// works
				System.out.println("B. Add Contacts ");// works
				System.out.println("C. Search by First Name ");// works
				System.out.println("D. Search by Last Name ");// works
				System.out.println("E. Search by Phone Number");// works
				System.out.println("F. Delete based on Phone ");
				System.out.println("G. Update based on Phone ");
				System.out.println("z. Exit program ");// works

				String userChoice = input.nextLine();

				switch (userChoice.charAt(0)) {

				case 'A': // Display Contacts

					System.out.println("\n________Here are the contacts________");
					System.out.println("_____________________________________\n\n");

					for (int i = 0; i < Repository.personList.length; i++) { // for loop set to length of People[]
																				// personList ++

						System.out.println(Repository.personList[i].toString()); // Prints the object at every index
																					// through the toString();

					} // for display loop

					break; // breaks run, returns back to do start

				case 'B': // Make a new entry

					System.out.println("\n___________Add New Entry______________");
					System.out.println("______________________________________ ");
					System.out.println("\nPlease use following format:\n"
							+ "firstname lastname, \nstreet, city, state, zip, phone number");

					String newInfo = input.nextLine(); // creates newInfo string set to the input in the next line

					createNewContact(newInfo); // createNewContact is called where the string is broken up
												// and sorted into an array for names/info and an array for addresses
					break; // breaks run and returns to do start

				case 'C': // Search by First Name

					System.out.println("\nPlease enter first name:");

					String firstName = input.nextLine(); // sets input at next line to string firstName

					System.out.println("\nHere is your record.");

					Person[] searchFirstName = Repository.searchFirstName(firstName);// creates an array of person
																						// objects equal to
					System.out.println("%%%%" + searchFirstName.length);

					for (int i = 0; i < searchFirstName.length; i++) {
						System.out.println(searchFirstName[i]);
						System.out.println();
					}

					break;

				case 'D': // Search by Last Name Number
					System.out.println("\nPlease enter Last Name:");
					String lastName = input.nextLine();

					System.out.println("\nHere is your record");

					Person[] searchLastName = Repository.searchLastName(lastName);
					System.out.println("%%%" + searchLastName.length);

					for (int i = 0; i < searchLastName.length; i++) {
						System.out.println(searchLastName[i]);
						System.out.println();
					}

					break;

				case 'E': // Search based on Phone Number
					System.out.println("\nPlease enter Phone Number:");
					String phoneNum = input.nextLine();
					System.out.println("\nHere is your record");

					Person searchPhoneNumber = Repository.searchPhoneNumber(phoneNum);
					System.out.println("%%%" + searchPhoneNumber);

					break;

				case 'F': // Delete based on Phone Number
					System.out.println("\nEnter Phone Number to delete record:");
					String person = input.nextLine();
					Repository.deletePerson(person);

					break;

				case 'G': // Update based on Phone Number
					System.out.println("\nEnter Phone Number to update ");
					updateMenu();
					break;

				case 'z':
					System.out.println("\n Goodbye.");

					isEnd = true;
				default:

					break;

				}// switch

			} // do

			while (isEnd != true);

		} // try
		catch (Exception e) {// catch
			System.out.println("\nInvalid input. Please re-enter " + "capital letter of options provided.\n");
			startMainMenu();// returns to the main menu prompt
		} // catch

	}

	private static void createNewContact(String newInfo) {
		String[] newInfoArray = newInfo.split(","); // takes in string of input and puts it into an array split by
													// commas

		String fullName = newInfoArray[0]; // creates a string for full name from index 0 of the string

		String[] nameArray = fullName.split(" "); // splits the string by the blank spaces to find first/last name and
													// puts in new array
		String firstName = nameArray[0]; // sets first name before the first space equal to first name at index 0
		String lastName = nameArray[nameArray.length - 1]; // sets the end of the array index before any commas to the
															// last name

		String street = newInfoArray[1]; // street to index 1
		String city = newInfoArray[2]; // ...
		String state = newInfoArray[3];
		String zip = newInfoArray[4];
		String phoneNum = newInfoArray[5]; // ...

		Addresses newAddress = new Addresses(street, city, state, zip); // creates new address object from input
		Person newPerson = new Person(fullName, firstName, lastName, newAddress, phoneNum); // creates new person object
																							// from input and address
																							// object

		Repository.addToList(newPerson);
	}// createNewContacts

	private static void updateMenu() {
		System.out.println("Please enter Phone Number to update associated account(s):\n");
		String numToSearch = input.nextLine();
		Person updateContact = Repository.searchPhoneNumber(numToSearch);

		System.out.println("What do you want to change?");
		System.out.println("A. Change street");
		System.out.println("B. Change city");
		System.out.println("C. Change state");
		System.out.println("D. Change zip");

		String updateChoice = input.nextLine();
		switch (updateChoice.charAt(0)) {// switch start

		case 'A':
			System.out.println("\nPlease enter new street");
			String newStreet = input.nextLine(); // creates new string set to next input
			updateContact.getAddress().setStreet(newStreet); // sets street to new street name entered
			System.out.println(updateContact); // prints updated contact

			break;

		case 'B':
			System.out.println("\nPlease enter new city");
			String newCity = input.nextLine();
			updateContact.getAddress().setCity(newCity);
			System.out.println(updateContact);

			break;

		case 'C':
			System.out.println("\nPlease enter new state");
			String newState = input.nextLine();
			updateContact.getAddress().setState(newState);
			System.out.println(updateContact);

			break;

		case 'D':
			System.out.println("\nPlease enter new zipcode");
			String newZip = input.nextLine();
			updateContact.getAddress().setState(newZip);
			System.out.println(updateContact);

			break;

		default:

			break;
		}// switch end

	}

}
