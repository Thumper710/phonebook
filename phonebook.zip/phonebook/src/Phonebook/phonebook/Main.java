package phonebook;

public class Main {

	public static void main(String[] args) {

		Menu.startMainMenu();

	}

}

//Alex Grant, 2532 Maple Crossing Drive, Wildwood, MO, 63011, 3143986407
//Libby Newsham, 1502 Crimson View Ct, Ellisville, MO, 63011, 3146065138
//Frank Ngeno, 1502 Washington Ave, St. Louis, MO, 63130, 9196497478