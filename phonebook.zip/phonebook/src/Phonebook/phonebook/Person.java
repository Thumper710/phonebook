package phonebook;

public class Person {

	private String firstName;
	private String lastName;
	private String fullName;
	private String phoneNum;
	private Addresses address;

	public Person() {
	};

	public Person(String fullName, String firstName, String lastName, Addresses address, String phoneNum) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.fullName = fullName;
		this.address = address;
		this.phoneNum = phoneNum;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return this.fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPhone() {
		return this.phoneNum;
	}

	public void setPhone(String phoneNum) {
		this.phoneNum = phoneNum;

	}

	public Addresses getAddress() {
		return this.address;
	}

	public void setPhone(Addresses address) {
		this.address = address;

	}

	@Override
	public String toString() {
		return fullName + "," + address + " (" + phoneNum.substring(1, 4) + ")-" + phoneNum.substring(4, 7) + "-"
				+ phoneNum.substring(7) + "\n";
	}

}
