package phonebook;

public class Repository {

	public static Person[] personList = new Person[0]; //

	public static void addToList(Person newPerson) { // addToList method sets personList to the value of the person
														// added

		personList = addPerson(newPerson, personList); // personList receives the new Person passed to it

	}

	public static Person[] addPerson(Person newPerson, Person[] array) {
		// addPerson creates a newArray to the size of the length of personList+1
		Person[] newArray = new Person[personList.length + 1];

		for (int i = 0; i < personList.length; i++) { // starting at index 0 , set the newArray equal to the personList
														// at every index

			newArray[i] = personList[i]; // every index of newArray is set equal to every index of personList

		}
		newArray[newArray.length - 1] = newPerson; // the newPerson is set to the most recently created index

		return newArray; // returns the updated Person[] newArray

	}

	public static void deletePerson(String newPerson) { // creates deletePerson method that returns nothing (void)
														// and is passed a String called newPerson
		Person[] searchArray = new Person[personList.length - 1]; // Creates a People[] called searchArray set tp the
																	// length
																	// of the personList array minus one to line up
																	// indexes

		int counter = 0; // counter created to measure/visualize the number of iterations
							// being executed
		for (int i = 0; i < personList.length; i++) { // creates a for loop set to the length of personList

			if (!personList[i].getPhone().strip().equals(newPerson)) { // if the last index position being evaluated
																		// doesn't match
				// the phone number being passed, then ...
				searchArray[counter] = personList[i]; // set the searchArray at whatever index the iteration is on to
														// the
														// matching index of the personList array
				counter++; // increases counter value by 1 after each execution of the loop
							// to match the for loop iteration
			}

		}

		personList = searchArray; // sets searchArray equal to the personList
									// which updates the personList to not have
		System.out.println("Deleted"); // the deleted value

	}

	public static Person[] getPerson() { // getter

		return personList;

	}

	public static Person[] searchFirstName(String firstName) { // works same as search last name
																// also same as delete except leaves the personList
																// unaffected
		int counter = 0;
		for (int i = 0; i < personList.length; i++) {
			if (personList[i].getFirstName().strip().equalsIgnoreCase(firstName)) { // checks input against ever index
																					// in the array
				counter++; // for every successful iteration,
			} // increase counter value by 1
		}
		Person[] searchArray = new Person[counter]; // creates a searchArray equal to to whatever index value at index
													// pos[counter]

		int x = 0; // initializes our second counter
		for (int i = 0; i < personList.length; i++) { // for the length of personList
			if (personList[i].getFirstName().strip().equalsIgnoreCase(firstName)) { // if the passed string equals to
																					// any index, set
																					// a corresponding index pos in
																					// searchArray equal to the same
																					// index pos in personList
				searchArray[x] = personList[i];
				x++; // increments second counter to check next index for match

			}
		}
		return searchArray; // returns this searchArray holding all matching first name records
	}

	public static Person[] searchLastName(String lastName) { // works
		int counter = 0;
		for (int i = 0; i < personList.length; i++) { // for loop that measures the successful run amount
			if (personList[i].getLastName().equalsIgnoreCase(lastName)) { // if the index at i in personList[] equals
																			// the lastName being passed,
				counter++; // then the counter will increment by one
			} // Having a counter in a matching for loop
				// is useful because it visualizes every successful execution of the loop
		}
		Person[] searchArray = new Person[counter];

		int x = 0;
		for (int i = 0; i < personList.length; i++) { // for loop to run through array
			if (personList[i].getLastName().equalsIgnoreCase(lastName)) { // if index i in personList == lastName, set
																			// searchArray
																			// to the string being passed and compare
																			// index by index
				searchArray[x] = personList[i]; // sets the arrays that pass the if statement equal to each
												// other at each index
				x++; // counter value increases for every index in array

			}
		}
		return searchArray; // returns the value at index i of Person[]personList,
							// which is set to equal to the new array searchArray,
							// and then searchArray is then returned
	}// searchLastName

	public static Person searchPhoneNumber(String phoneNum) { // works same as search first and last name

		for (int i = 0; i < personList.length; i++) {
			if (personList[i].getPhone().strip().equalsIgnoreCase(phoneNum)) {
				return personList[i];

			} // if
		} // for
		return null;
	}// searchPhoneNumber

	public static Person updateSearch(String phoneNum) {
		int counter = 0; // creates a counter
		for (int i = 0; i < personList.length; i++) { // for the length of personList array
			if (personList[i].getPhone().strip().equalsIgnoreCase(phoneNum)) { // if index at i equals the phone number
																				// entered
				counter++; // increase counter value
			} // if
		} // for
		Person[] updateArray = new Person[counter]; // creates an array where size is set to the value of the counter

		int x = 0; // creates another counter
		for (int i = 0; i < personList.length; i++) { // same for as above
			if (personList[i].getPhone().strip().equalsIgnoreCase(phoneNum)) { // same if as above

				updateArray[x] = personList[i]; // for ever iteration this loop sets every index of updateArray =
												// personList
				x++;

			} // if
		} // for
		return updateArray[x];
	}// searchPhoneNumber

}
